# 美本申请叙事：从一座没有出现的工厂开始

## 30秒讲清楚

我曾经追踪一座签约后没有建成的工厂。那件事让我产生一个更大的问题：它是例外，还是地方招商中经常被忽略的一段？

于是我做了Unbuilt Atlas。我把南阳官方报道中的招商项目逐项列出来，几年后再查投产、施工、审批和企业记录，最后做成一张任何人都能点开、回到原始来源核对的地图。

我发现，问题甚至早于项目是否建成。21篇主要签约报道宣布了426个项目名额，只有14.6%在同一篇报道中被明确点名。在我能够追踪的80个项目中，只有17.5%留下了强物理里程碑。更有名的企业和更大的签约场面都没有显示出更高的兑现率。

## 这个故事为什么成立

故事的起点很小：一座没有出现的工厂。

第二步不是马上下结论，而是承认自己不知道它是不是个例。你把怀疑变成了一个可以数的问题。

第三步是最能体现独立性的地方。你没有停在几篇新闻或几个案例，而是自己定义纳入标准、建立项目身份、写检索脚本、逐条审定证据、做统计检验，再把判断公开给别人挑战。

第四步是克制。你没有把“没查到”写成“没建成”，也没有为了得到一个显著结果强行拟合金额模型。招生官看到的不是一个会做漂亮网页的人，而是一个愿意让自己的结论受约束的人。

最后，问题回到人。签约失败不是抽象的行政数字。它可能改变土地用途、就业预期、财政支出和一个家庭是否决定留下。

## Common App活动描述草稿

**Position/Leadership:** Founder and researcher, Unbuilt Atlas  
**Organization:** Independent civic data project  
**Description, 150 characters:** Tracked 80 public investment projects from signing to construction; built an open evidence map and policy brief on why promises disappear.

## 英文长版叙事骨架

I started with one factory that never appeared.

The government announcement had names, numbers, handshakes, and a headline investment figure. What it did not have was an ending. Years later, I could not tell whether the project had opened, moved, changed names, or quietly disappeared.

That gap bothered me more than the missing factory. If a public promise could vanish without leaving a trail, how many other projects had done the same?

I built a list. Then the list became a dataset, the dataset became an audit, and the audit became a map. I followed 80 named projects across Nanyang from their signing announcements to later records of construction, permits, production, or silence. I kept every source link and wrote rules before reading the outcomes. When a search found nothing, I recorded exactly that instead of declaring failure.

The strongest finding came before construction. Official reports announced 426 project slots, but named only 14.6 percent of them in the same article. Most promises could not be tracked from day one. Among the 80 projects I could identify, 17.5 percent left a strong physical milestone. Famous companies and larger ceremonies did not predict better outcomes.

The project changed how I think about evidence. A map is not useful because it looks definitive. It is useful when every point tells a reader what is known, what is not known, and where to check.

## 可以继续深化的功能

1. 扩展到河南18个地级市，形成跨城市同口径队列。
2. 建立宗地多边形和真实影像拍摄日期，升级为地块级前后对比。
3. 接入环评、施工许可、企业注册、用电和税收等结构化里程碑。
4. 设计“项目承诺账本”，让政府或媒体按季度更新下一节点。
5. 开放公众提交证据，但保留双人复核和来源等级。
6. 比较不同城市的公开透明度，而不是只比较落地率。
7. 追踪项目失败后土地、就业和财政激励如何被重新安排。
8. 访谈项目周边居民，把宏观兑现率连接到具体生活选择。

## 最适合申请材料的标题

- After the Handshake
- Where Promises Go
- The Missing Factory
- Unbuilt Atlas
- 签约之后

